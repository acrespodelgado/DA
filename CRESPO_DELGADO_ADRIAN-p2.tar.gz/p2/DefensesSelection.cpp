// ###### Config options ################


// #######################################

#define BUILDING_DEF_STRATEGY_LIB 1

#include "../simulador/Asedio.h"
#include "../simulador/Defense.h"
#include<algorithm>

using namespace Asedio;

double defenseValue(Defense* defense) {
    return (0.4 * (defense->range / 50) + 0.4 * (defense->attacksPerSecond / 2) + 0.2 * (defense->health / 700)) / (defense->cost/200.0);
}

std::vector<double> getValues(std::list<Defense*> defenses) {
    std::vector<double> Values;
    for(auto it : defenses) {
        Values.push_back(defenseValue(it));
    }
    return Values;
}

std::vector<double> getPrices(std::list<Defense*> defenses) {
    std::vector<double> Prices;
    for(auto it : defenses) {
        Prices.push_back(it->cost);
    }
    return Prices;
}

std::list<int> getDefenses(std::list<Defense*> defenses, int ases) {
    std::list<int> solution;
    
    Defense* base = defenses.front();
    defenses.pop_front();

    ases -= base->cost;
    int k = ases;

    std::vector<double> Values = getValues(defenses);
    std::vector<double> Prices = getPrices(defenses); 
    std::vector<std::vector<double>> Table;

    solution.push_back(base->id);

    for(int i = 0 ; i < Values.size(); ++i) {
        std::vector<double> vectorAux(ases + 1);
        Table.push_back(vectorAux);

        for(int j = 0 ; j < ases + 1; ++j) {
            if(i == 0) 
               j < Prices[i] ? Table[i][j] = 0 : Table[i][j] = Values[i];
            else
               j < Prices[i] ? Table[i][j] = Table[i-1][j] : Table[i][j] = std::max(Table[i-1][j], Table[i-1][j - Prices[i]] + Values[i]);
        }
    }

    for(int i = Values.size() - 1; i > 0; i--) {
        if(Table[i][k] != Table[i-1][k]) {
            solution.push_back(defenses.back()->id);
            defenses.pop_back();
            k -= Prices[i];
        }   
    }

    if(Table[0][k] != 0) {
        solution.push_back(defenses.front()->id);
        k -= Prices[0];
    }
    
    return solution;
}


void DEF_LIB_EXPORTED selectDefenses(std::list<Defense*> defenses, unsigned int ases, std::list<int> &selectedIDs
            , float mapWidth, float mapHeight, std::list<Object*> obstacles) {
    selectedIDs = getDefenses(defenses, ases);
}
