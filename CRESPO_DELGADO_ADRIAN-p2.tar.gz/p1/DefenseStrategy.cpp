// ###### Config options ################

//#define PRINT_DEFENSE_STRATEGY 1    // generate map images

// #######################################

#define BUILDING_DEF_STRATEGY_LIB 1

#include "../simulador/Asedio.h"
#include "../simulador/Defense.h"

#ifdef PRINT_DEFENSE_STRATEGY
#include "ppm.h"
#endif

#ifdef CUSTOM_RAND_GENERATOR
RAND_TYPE SimpleRandomGenerator::a;
#endif

using namespace Asedio;

struct Cell
{
    int row;
    int col;
    float cellValue;

    Cell(int r, int c, float v) : row{r}, col{c}, cellValue{v} {}
};

//Recibe ancho con columnas o alto con filas: i + y, j + x

float cellCenter(int index, float sizeC)
{
    return index * sizeC + (sizeC / 2);
}

bool factibleCell(bool **freeCells, float mapWidth, float mapHeight, List<Object *> obstacles, Defense *defense, List<Defense *> defenses, Cell cell, float cellWidth, float cellHeight)
{
    float centerX = cellCenter(cell.col, cellWidth);
    float centerY = cellCenter(cell.row, cellHeight);

    bool factible = freeCells[cell.row][cell.col] && mapWidth > centerX + defense->radio && mapHeight > centerY + defense->radio &&

                    centerX - defense->radio > 0 && centerY - defense->radio > 0;

    for (auto i = obstacles.begin(); i != obstacles.end() && factible; ++i)
    {

        //_distance se usa en asedio.h, en el define

        factible = defense->radio + (*i)->radio < _distance((*i)->position, Vector3(centerX, centerY));
    }

    for (auto i = defenses.begin(); i != defenses.end() && factible; ++i)
    {
        //_distance se usa en asedio.h, en el define, como est� el using namespace no necesito poner Asedio::_distance
        factible = defense->radio + (*i)->radio < _distance((*i)->position, Vector3(centerX, centerY));
    }

    return factible;
}

float cellValue(float compareToCenterX, float compareToCenterY, float cellCenterX, float cellCenterY)
{
    //La inversa para que sea lo mas alto posible y tenga el maximo valor
    return (100 / _distance(Vector3(compareToCenterX, compareToCenterY), Vector3(cellCenterX, cellCenterY)));
}

bool compareCell(Cell cell1, Cell cell2)
{
    return cell1.cellValue > cell2.cellValue;
}

List<Cell> getCandidatesBase(float mapWidth, float mapHeight, int nCellsWidth, int nCellsHeight, float cellWidth, float cellHeight)
{
    List<Cell> candidates;

    for (int i = 0; i < nCellsHeight; ++i)
    {
        for (int j = 0; j < nCellsWidth; ++j)
        {
            candidates.push_back(Cell(i, j, cellValue(mapWidth / 2, mapHeight / 2, cellCenter(j, cellWidth), cellCenter(i, cellHeight))));
        }
    }

    //Ordena de mayor a menor

    candidates.sort(compareCell);

    return candidates;
}

List<Cell> getCandidatesDefenses(float baseCenterX, float baseCenterY, int nCellsWidth, int nCellsHeight, float cellWidth, float cellHeight)
{
    List<Cell> candidates;

    for (int i = 0; i < nCellsHeight; ++i)
    {
        for (int j = 0; j < nCellsWidth; ++j)
        {
            candidates.push_back(Cell(i, j, cellValue(baseCenterX, baseCenterY, cellCenter(j, cellWidth), cellCenter(i, cellHeight))));
        }
    }

    //Ordena de mayor a menor

    candidates.sort(compareCell);

    return candidates;
}

void DEF_LIB_EXPORTED placeDefenses(bool **freeCells, int nCellsWidth, int nCellsHeight, float mapWidth, float mapHeight, std::list<Object *> obstacles, std::list<Defense *> defenses)
{
    float cellWidth = mapWidth / nCellsWidth;
    float cellHeight = mapHeight / nCellsHeight;

    List<Defense *>::iterator currentDefense = defenses.begin();

    bool placed = false;
    List<Cell> candidatesBase = getCandidatesBase(mapWidth, mapHeight, nCellsWidth, nCellsHeight, cellWidth, cellHeight);

    while (!placed && !candidatesBase.empty())
    {
        Cell currentCell = candidatesBase.front();
        candidatesBase.pop_front();
        if (factibleCell(freeCells, mapWidth, mapHeight, obstacles, *currentDefense, defenses, currentCell, cellWidth, cellHeight))
        {
            (*currentDefense)->position.x = currentCell.col * cellWidth + cellWidth * 0.5f;
            (*currentDefense)->position.y = currentCell.row * cellHeight + cellHeight * 0.5f;
            (*currentDefense)->position.z = 0;
            placed = true;
        }
    }

    List<Cell> candidatesDefenses = getCandidatesDefenses((*currentDefense)->position.x, (*currentDefense)->position.y, nCellsWidth, nCellsHeight, cellWidth, cellHeight);

    ++currentDefense;

    while (currentDefense != defenses.end())
    {
        placed = false;
        while (!placed && !candidatesDefenses.empty())
        {
            Cell currentCell = candidatesDefenses.front();
            candidatesDefenses.pop_front();
            if (factibleCell(freeCells, mapWidth, mapHeight, obstacles, *currentDefense, defenses, currentCell, cellWidth, cellHeight))
            {
                (*currentDefense)->position.x = currentCell.col * cellWidth + cellWidth * 0.5f;
                (*currentDefense)->position.y = currentCell.row * cellHeight + cellHeight * 0.5f;
                (*currentDefense)->position.z = 0;
                placed = true;
            }
        }
        ++currentDefense;
    }

#ifdef PRINT_DEFENSE_STRATEGY

    float **cellValues = new float *[nCellsHeight];
    for (int i = 0; i < nCellsHeight; ++i)
    {
        cellValues[i] = new float[nCellsWidth];
        for (int j = 0; j < nCellsWidth; ++j)
        {
            cellValues[i][j] = ((int)(cellValue(i, j))) % 256;
        }
    }
    dPrintMap("strategy.ppm", nCellsHeight, nCellsWidth, cellHeight, cellWidth, freeCells, cellValues, std::list<Defense *>(), true);

    for (int i = 0; i < nCellsHeight; ++i)
        delete[] cellValues[i];
    delete[] cellValues;
    cellValues = NULL;

#endif
}
